# @forgesworn/joystick-protocol

Wire types for the joystick phone-as-controller protocol.

This package exports the TypeScript types and constants that describe the over-the-wire shape between the broker, the host (game), and the phone (PWA). It has zero runtime dependencies.

## What's here

- `ControllerSpec` and per-slot config for the host-to-PWA layout descriptor.
- `ControllerInputFrame` (`{k, v}`) for PWA-to-host input frames.
- `ControllerSlot` enum-string union.
- Identity / signer types: `SignerAnnounceFrame`, `SignerRevokeFrame`, `SignRequestFrame`, `SignResponseFrame`, `SignerCaps`.
- `PairingToken` shape (carried in the QR URL).
- `CONTROLLER_WS_ENDPOINT_DEFAULT` constant.

## Controller version

`PairingToken.version: 2` selects protected host ownership. Omitted versions
select the legacy namespace. The visible session code admits a controller;
the private host credential belongs only in the host's initial WebSocket frame.
Keep the version when parsing, storing, reviewing and transferring a token.

## Legacy protocol mirror

`scripts/check-protocol-sync.sh` is a manually invoked comparison with the older
Pallasite inline types. It compares complete files byte for byte, including
comments; it is not a required Joystick CI gate. Joystick's recovery and v2
additions require an explicit downstream migration before that legacy copy can
match. Do not change a downstream game's transport merely to satisfy this
historical mirror check. Current games consume this workspace package directly.

## Supported controller contract

Spec version 1 supports heading, XY and Tilt. Heading values are radians × 1000;
XY uses `<slot>-x`/`<slot>-y` in [-1000,1000], with down-positive Y. Neutralise
thrust, power and axes on cancellation/background/disconnect; cancellation must
never emit tap-fire. Typed `ControllerFeedbackFrame` carries host-owned text,
selected slot, lock and tone. Guests/names do not establish signing authority.
The native clients and their shared vectors are documented in `native/README.md`.
